int main() {
  int(*a)();
  if(0)
  {
    int(*main)();
  }else
  {
    int a;
  }
  main = a;
  return;
}